export interface pessoa {
    nome:string;
    email:string;
    sobrenome: string;
    idade: number;
    sexo: string;
    foto: string;
}