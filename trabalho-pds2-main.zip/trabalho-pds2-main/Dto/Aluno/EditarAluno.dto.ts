export interface EditarAlunoDto {
    matricula:string;
    curso:string;
};