export interface EditarMateriaDto {
    nome:string;
    codigo:string;
    departamento:string;
    preRequisito:object,
    horas:number;
}