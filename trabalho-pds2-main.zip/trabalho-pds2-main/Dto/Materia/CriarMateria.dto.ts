export interface CriarMateriaDto{
    nome: string;
    codigo: string;
    departamento: string;
    preRequisito: object;
    horas: string;
    status:number
}