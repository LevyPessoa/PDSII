export interface AtualizarPessoaDto{
    nome:string;
    sobrenome:string;
    email:string;
    idade:number;
    telefone:number;
    tipo:string;
}