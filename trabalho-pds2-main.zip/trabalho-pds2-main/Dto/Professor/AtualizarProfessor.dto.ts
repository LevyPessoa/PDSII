export interface AtualizarProfessorDto {
    departamento:string;
    formacao:string;
    sala:string;
    status:number;
}