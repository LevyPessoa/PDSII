export interface CreatedPersonDto{
    nome: string;
    sobrenome: string;
    email: string;
    senha: string;
    idade: number;
    sexo: string;
    foto: string;
    tipo:string
}