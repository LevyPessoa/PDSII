const listarTurmasAluno = async () => {
    try{
        
    }catch(erro){

    }
};


listarTurmasAluno();