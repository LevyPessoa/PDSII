export interface MessageReturnDto {
    status:number,
    content:any
}